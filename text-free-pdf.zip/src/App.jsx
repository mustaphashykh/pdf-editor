// import { rgb } from 'pdf-lib';
import { useState } from 'react';
// import { PDFDocument } from 'pdf-lib';
import FileUpload from './components/FileUpload';
import axios from 'axios';

const App = () => {
  const [pdfFile, setPdfFile] = useState(null);
  // const [newPdfBlob, setNewPdfBlob] = useState(null);

  const handleFileUpload = file => {
    setPdfFile(file);
  };

  // const processPDF = async () => {
  //   const existingPdfBytes = await pdfFile.arrayBuffer();
  //   const pdfDoc = await PDFDocument.load(existingPdfBytes);

  //   // Remove text from each page (example, you'll need to refine this)
  //   const pages = pdfDoc.getPages();

  //   pages.forEach(page => {
  //     const { width, height } = page.getSize();
  //     page.drawRectangle({
  //       x: 0,
  //       y: 0,
  //       width: width,
  //       height: height,
  //       color: rgb(1, 1, 1),
  //     });
  //   });

  //   const pdfBytes = await pdfDoc.save();
  //   setNewPdfBlob(new Blob([pdfBytes], { type: 'application/pdf' }));
  // };
  const sendPDF = async () => {
    if (!pdfFile) return alert("Please upload a PDF file");
    const formData = new FormData();

    formData.append("pdf", pdfFile);
    const response = await axios.post("http://localhost:5000/pdf", formData)
    console.log(response.data)
  }
  return (
    <div>
      <FileUpload onFileUpload={handleFileUpload} />
      {<button style={{margin: '10px'}} onClick={sendPDF}>Generate PDF</button>}
      {/* {newPdfBlob && <a href={URL.createObjectURL(newPdfBlob)} download="new-pdf.pdf">Download New PDF</a>} */}
    </div>
  );
};

export default App;
