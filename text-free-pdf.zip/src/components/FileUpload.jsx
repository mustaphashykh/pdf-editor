/* eslint-disable react/prop-types */
import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';

const FileUpload = ({ onFileUpload }) => {
    const onDrop = useCallback(acceptedFiles => {
        onFileUpload(acceptedFiles[0]);
    }, [onFileUpload]);

    const { getRootProps, getInputProps } = useDropzone({
        onDrop,
        accept: 'application/pdf'
    });

    return (
        <div {...getRootProps()} style={{ width: '350px', height: '200px', borderRadius: '10px', border: "1px dashed gray", display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <input {...getInputProps()} />
            <p>Drag n drop a PDF here, or click to select a PDF</p>
        </div>
    );
};

export default FileUpload;
